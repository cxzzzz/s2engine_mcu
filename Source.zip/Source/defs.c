
#include "defs.h"



S2CHIP_STATUS s2chip_status;

struct _PPU_CTRL* PPU_CTRL = (struct _PPU_CTRL*) PPU_BASE_ADDR ;
struct _PE_CTRL* 	PE_CTRL = (struct _PE_CTRL*)(PE_BASE_ADDR);
struct _FM_CTRL*	FM_CTRL = (struct _FM_CTRL*)(FM_BASE_ADDR);
struct _WM_CTRL* WM_CTRL = (struct _WM_CTRL*)(WM_BASE_ADDR);
struct _SDRAM_CTRL* SDRAM_CTRL = (struct _SDRAM_CTRL*) SDRAM_BASE_ADDR;




